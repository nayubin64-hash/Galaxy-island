# Galaxy Island 1.0

Starter Android Studio project for a Dynamic-Island-style overlay on Samsung Galaxy Z / Android 16.

## Included
- Floating black pill overlay using `TYPE_APPLICATION_OVERLAY`
- Tap to expand/collapse
- Charging-state indicator
- Notification-listener service scaffold
- Setup screen for overlay and notification permissions

## Build
1. Install Android Studio with Android SDK 36.
2. Open this folder as a project.
3. Allow Gradle sync.
4. Connect a Samsung Galaxy Z device with USB debugging, or use wireless debugging.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Setup on phone
1. Install the APK.
2. Open Galaxy Island.
3. Grant "Display over other apps".
4. Enable Galaxy Island notification access in Android notification access settings.
5. Tap "Bật Galaxy Island".

## Notes
This is an initial MVP scaffold, not a Play Store-ready release. Android 16 / One UI background and overlay behavior can vary by device and firmware. Notification text is opt-in and may be hidden by the source app or Android privacy settings. The notification listener currently broadcasts updates; a follow-up integration can connect the receiver to the running overlay service reliably. Battery charging status is supported in this starter version.
