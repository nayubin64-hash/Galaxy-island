plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.galaxyisland.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.galaxyisland.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
