package com.galaxyisland.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
import android.widget.*
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245,245,247)
        window.navigationBarColor = Color.rgb(245,245,247)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(24))
            setBackgroundColor(Color.rgb(245,245,247))
        }
        val title = TextView(this).apply {
            text = "Galaxy Island"
            textSize = 30f
            setTextColor(Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Dynamic Island cho Galaxy Z · Android 16"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(6), 0, dp(24))
        }
        val preview = TextView(this).apply {
            text = "      ●  Galaxy Island  "
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            setPadding(dp(12), dp(18), dp(12), dp(18))
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(preview, LinearLayout.LayoutParams(-1, dp(66)))
        root.addView(TextView(this).apply {
            text = "Thiết lập quyền"
            textSize = 19f
            setTextColor(Color.BLACK)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(28), 0, dp(12))
        })
        root.addView(actionButton("1. Cấp quyền hiển thị trên ứng dụng khác") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        })
        root.addView(actionButton("2. Cho phép truy cập thông báo") {
            startActivity(Intent(ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(actionButton("Bật Galaxy Island") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Hãy cấp quyền hiển thị trước", Toast.LENGTH_LONG).show()
            } else {
                startForegroundService(Intent(this, IslandOverlayService::class.java))
                Toast.makeText(this, "Galaxy Island đã được bật", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(actionButton("Tắt Galaxy Island") {
            stopService(Intent(this, IslandOverlayService::class.java))
        })
        root.addView(TextView(this).apply {
            text = "Lưu ý: Để hiển thị nội dung thông báo, hãy bật quyền truy cập thông báo cho Galaxy Island trong Cài đặt. Ứng dụng không đọc mật khẩu hay nội dung ngoài thông báo hệ thống."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, dp(22), 0, 0)
        })
        setContentView(root)
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(10)
            layoutParams = lp
        }
}
