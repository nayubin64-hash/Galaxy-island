package com.galaxyisland.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Intent

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        // Notification access is opt-in. Broadcast only short display text to the overlay.
        sendBroadcast(Intent("com.galaxyisland.app.NEW_NOTIFICATION").apply {
            setPackage(packageName)
            putExtra("title", title)
            putExtra("text", text)
        })
    }
}
