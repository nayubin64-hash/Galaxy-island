package com.galaxyisland.app

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.*
import android.view.*
import android.widget.*
import android.content.pm.ServiceInfo

class IslandOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var island: LinearLayout? = null
    private var expanded = false
    private var latestTitle = "Galaxy Island"
    private var latestText = "Đang hoạt động"
    private var charging = false

    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            latestTitle = intent?.getStringExtra("title") ?: latestTitle
            latestText = intent?.getStringExtra("text") ?: latestText
            updateContent()
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                val status = intent.getIntExtra("status", -1)
                charging = status == 2 || status == 5
                updateContent()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val notificationFilter = IntentFilter("com.galaxyisland.app.NEW_NOTIFICATION")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(notificationReceiver, notificationFilter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(notificationReceiver, notificationFilter)
        }
        showIsland()
    }

    private fun startAsForeground() {
        val channelId = "galaxy_island_service"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Galaxy Island", NotificationManager.IMPORTANCE_LOW))
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Galaxy Island đang chạy")
            .setContentText("Chạm vào viên thuốc để mở rộng")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(10, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(10, notification)
    }

    private fun showIsland() {
        val density = resources.displayMetrics.density
        fun d(v: Int) = (v * density).toInt()
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(d(16), d(9), d(16), d(9))
            setBackgroundColor(Color.BLACK)
        }
        container.background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.BLACK)
            cornerRadius = d(32).toFloat()
        }
        container.addView(TextView(this).apply {
            text = "●   Galaxy Island"
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            tag = "headline"
        })
        val detail = TextView(this).apply {
            text = "Chạm để xem thông tin"
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            visibility = View.GONE
            tag = "detail"
            setPadding(0, d(6), 0, 0)
        }
        container.addView(detail)
        container.setOnClickListener {
            expanded = !expanded
            updateContent()
            val params = container.layoutParams as WindowManager.LayoutParams
            params.width = if (expanded) d(300) else d(172)
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            wm.updateViewLayout(container, params)
        }
        val params = WindowManager.LayoutParams(
            d(172), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = d(8)
        }
        island = container
        wm.addView(container, params)
        updateContent()
    }

    private fun updateContent() {
        val v = island ?: return
        val density = resources.displayMetrics.density
        val headline = v.findViewWithTag<TextView>("headline")
        val detail = v.findViewWithTag<TextView>("detail")
        headline?.text = if (charging) "⚡  Đang sạc pin" else "●  Galaxy Island"
        detail?.text = if (latestTitle != "Galaxy Island") "$latestTitle · $latestText"
                       else if (charging) "Thiết bị đang được sạc" else "Chạm để mở rộng"
        detail?.visibility = if (expanded) View.VISIBLE else View.GONE
        v.animate().scaleX(if (expanded) 1.04f else 1f).scaleY(if (expanded) 1.04f else 1f)
            .setDuration(180).start()
    }

    fun updateNotification(title: String, text: String) {
        latestTitle = title.take(45)
        latestText = text.take(90)
        updateContent()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(notificationReceiver) } catch (_: Exception) {}
        island?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        island = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
